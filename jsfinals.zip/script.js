// Variables for menu and buttons
const menuPanel = document.getElementById("menuPanel");
const toggleMusicButton = document.getElementById("toggleMusic");
let musicPlaying = false;

// Toggle the slide-in menu
function toggleMenu() {
    const menuPanel = document.getElementById("menuPanel");
    const hamburger = document.getElementById("hamburger");

    // Toggle active state for both menu and hamburger
    menuPanel.classList.toggle("active");
    hamburger.classList.toggle("active");
}


// Restart the p5.js sketch
function restartSketch() {
    window.location.reload();
}

function toggleMusic() {
    const button = document.getElementById("toggleMusic");

    // Check if audio is defined and loaded
    if (typeof audio !== 'undefined' && audio.isLoaded()) {
        if (musicPlaying) {
            audio.pause();
            console.log("Audio paused");
            button.textContent = "MUSIC: OFF";
        } else {
            audio.loop();  // Use loop to keep it playing
            console.log("Audio playing");
            button.textContent = "MUSIC: ON";
        }

        musicPlaying = !musicPlaying;
    } else {
        console.error("Audio is not loaded or not available");
    }
}


function toggleText() {
    const textOverlay = document.getElementById("textOverlay");
    const showTextButton = document.getElementById("showText");
  
    // Check if the text is currently visible
    if (textOverlay.style.display === "none" || !textOverlay.classList.contains('show')) {
      // Change the text content here
      textOverlay.textContent = "Web by Lia, Inspo Sayama, Music Too Close by Peter Spacey"; // Change this to your desired text
  
      // Show the text with a fade-in effect
      textOverlay.style.display = "block";
      setTimeout(() => {
        textOverlay.classList.add('show'); // Trigger fade-in
      }, 10); // Minimal delay to allow the display change to take effect
  
      showTextButton.textContent = "HIDE TEXT";
    } else {
      // Trigger fade-out effect
      textOverlay.classList.remove('show'); // Remove fade-in class to start fade-out
  
      // After the fade-out completes, hide the text and change button text
      setTimeout(() => {
        textOverlay.style.display = "none"; // Hide text after fading out
        showTextButton.textContent = "SHOW TEXT"; // Reset button text
      }, 500); // Match the duration of the fade-out (500ms)
    }
  }
  
  
  