let bg;
let audio; // Audio file or microphone input

let depthFactor = 20; // Change this value to control the depth effect
let rotationOffset = 0; // Global variable for the ongoing rotation


// Array of color palettes
const palettes = [
  createCols("https://coolors.co/2a2b2a-706c61-f0f0ef-e42d5b"), // Palette 1 red,white,black,gray
  createCols("https://coolors.co/ea526f-070600-f7f7ff-23b5d3"), // Palette 2 above but theres blue
  createCols("https://coolors.co/080708-3772ff-df2935-fdca40"), // Palette 3 cool low sats
  createCols("https://coolors.co/ffffff-00a7e1-00171f-003459"), // Palette 4 blues
];

let COL; // Current palette

function setup() {
  createCanvas(windowWidth, windowHeight);
  background(100);
  bg = createGraphics(width, height);
  bg.background(255, 20);

  // Load audio and set up looping (but won't start immediately)
  audio = loadSound('Too Close.mp3', () => {
    console.log("Audio loaded successfully");
    // Don't call audio.loop() here to avoid immediate looping
  });

  // Randomly select a palette
  COL = random(palettes);

  bg.noStroke();
  for (let i = 0; i < 300000; i++) {
    let x = random(width);
    let y = random(height);
    let s = noise(x * 0.01, y * 0.01) * 2;
    bg.fill(240, 50);
    bg.rect(x, y, s, s);
  }
}

function draw() {
  randomSeed(0);
  noStroke();
  let mouseXPos = map(mouseX, 0, width, -depthFactor, depthFactor);
  let mouseYPos = map(mouseY, 0, height, -depthFactor, depthFactor);

  for (let i = 0; i < 25; i++) {
    fill(COL[int(random(COL.length))]);
    let s = random(20, 150) * (random(1, 2) + (sin(frameCount / 100 + random(100)) + 1) * 0.5);

    // Apply depth factor for movement (objects will move at different speeds based on their distance)
    let x = (random(width) + frameCount * random(1, 10) + mouseXPos) % (width + s) - s;
    let y = (random(height) + sin(frameCount / 100) * height * random(0.2, 1) + height + mouseYPos) % (height + s) - s;

    // Calculate the rotation angle based on movement direction
    let speedX = random(1, 5);  // X movement speed
    let speedY = random(1, 5);  // Y movement speed
    let rotationAngle = atan2(speedY, speedX); // Calculate angle of movement

    // Slight continuous rotation over time
    rotationOffset += 0.0001; // Increment rotation over time

    // Draw sharp star diamond shape with rotation
    drawStarDiamond(x, y, s, rotationAngle + rotationOffset);
  }
  image(bg, 0, 0);
}

function drawStarDiamond(x, y, size, angle) {
  let angleOffset = TWO_PI / 4; // Divide the circle into 4 parts (each 90 degrees)
  push();
  translate(x, y);  // Move to the center of the diamond
  rotate(angle);    // Rotate the diamond based on the angle + time-based rotation

  beginShape();
  for (let i = 0; i < 4; i++) {
    let x1 = cos(angleOffset * i) * size;  // Outer points of the star
    let y1 = sin(angleOffset * i) * size;  // Outer points of the star
    let x2 = cos(angleOffset * (i + 0.5)) * (size / 2);  // Inner points of the star
    let y2 = sin(angleOffset * (i + 0.5)) * (size / 2);  // Inner points of the star
    vertex(x1, y1);
    vertex(x2, y2);
  }
  endShape(CLOSE);
  pop();
}

function createCols(_url) {
  let slash_index = _url.lastIndexOf('/');
  let pallate_str = _url.slice(slash_index + 1);
  let arr = pallate_str.split('-');
  for (let i = 0; i < arr.length; i++) {
    arr[i] = '#' + arr[i];
  }
  return arr;
}


